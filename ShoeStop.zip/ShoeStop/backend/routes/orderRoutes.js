import { Router } from "express";
import { createOrder, listOrders, getOrder } from "../controllers/orderController.js";
import { validate, schemas } from "../utils/validate.js";

const router = Router();

router.get("/", listOrders);
router.get("/:id", getOrder);
router.post("/", validate(schemas.createOrder), createOrder);

export default router;
