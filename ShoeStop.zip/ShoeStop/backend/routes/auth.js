const express = require('express');
const router = express.Router();

// your route handlers, e.g.,
router.post('/register', async (req, res) => {
  // ... your register logic
});

router.post('/login', async (req, res) => {
  // ... your login logic
});

module.exports = router;  // <-- make sure you export the router, not an object or something else
