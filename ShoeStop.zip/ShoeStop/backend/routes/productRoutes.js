import { Router } from "express";
import {
  createProduct,
  listProducts,
  getProduct,
  updateProduct,
  deleteProduct
} from "../controllers/productController.js";
import { validate, schemas } from "../utils/validate.js";

const router = Router();

router.get("/", listProducts);
router.get("/:id", getProduct);
router.post("/", validate(schemas.createProduct), createProduct);
router.put("/:id", updateProduct);
router.delete("/:id", deleteProduct);

export default router;
