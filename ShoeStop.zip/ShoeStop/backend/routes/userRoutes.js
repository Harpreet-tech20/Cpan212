import { Router } from "express";
import { createUser, listUsers } from "../controllers/userController.js";
import { validate, schemas } from "../utils/validate.js";

const router = Router();

router.get("/", listUsers);
router.post("/", validate(schemas.createUser), createUser);

export default router;
