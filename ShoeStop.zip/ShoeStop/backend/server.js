// server.js (ESM)

// 1) Env + core deps
import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import mongoose from "mongoose";
import dns from "dns";

// Use public DNS resolvers to avoid SRV lookup issues on some networks
dns.setServers(["8.8.8.8", "1.1.1.1"]);

// 2) Local middleware
import notFound from "./middleware/notFound.js";
import errorHandler from "./middleware/errorHandler.js";

// 3) Routes (these files must exist and use .js extensions)
import userRoutes from "./routes/userRoutes.js";
import productRoutes from "./routes/productRoutes.js";
import orderRoutes from "./routes/orderRoutes.js";

// Optional: auth route (won’t crash if missing)
let authRoutes = null;
try {
  const mod = await import("./routes/auth.js");
  authRoutes = mod.default ?? mod;
} catch { /* no auth route; ignore */ }

// 4) App init + global middleware
const app = express();
app.use(helmet());
app.use(cors());
app.use(morgan("dev"));
app.use(express.json());

// 5) Friendly home + health
app.get("/", (_req, res) => {
  res.json({
    name: "ShoeStop API",
    status: "ok",
    docs: {
      health: "/api/health",
      users: "/api/users",
      products: "/api/products",
      orders: "/api/orders"
    }
  });
});

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// 6) Mount API routes
if (authRoutes) app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/products", productRoutes);
app.use("/api/orders", orderRoutes);

// 7) 404 + error handler (order matters)
app.use(notFound);
app.use(errorHandler);

// 8) Start after DB connects
const PORT = process.env.PORT || 5000;
const URI = process.env.MONGODB_URI;           // from .env
const DB_NAME = process.env.DB_NAME || "shoestop_db";

(async () => {
  try {
    if (!URI) throw new Error("MONGODB_URI is missing in .env");

    await mongoose.connect(URI, {
      dbName: DB_NAME,
      serverSelectionTimeoutMS: 5000, // fail fast during debugging
      family: 4                       // prefer IPv4; avoids some IPv6 quirks
    });

    console.log(`✅ MongoDB connected → ${DB_NAME}`);

    const server = app.listen(PORT, () => {
      console.log(`🚀 Server running at http://localhost:${PORT}`);
    });

    // Graceful shutdown
    const shutdown = () => {
      console.log("\nShutting down...");
      server.close(() => {
        mongoose.connection.close(false, () => {
          console.log("🔌 MongoDB connection closed");
          process.exit(0);
        });
      });
    };
    process.on("SIGINT", shutdown);
    process.on("SIGTERM", shutdown);
    process.on("unhandledRejection", (err) => {
      console.error("Unhandled Rejection:", err);
      shutdown();
    });
  } catch (err) {
    console.error("❌ Startup error:", err.message);
    process.exit(1);
  }
})();
