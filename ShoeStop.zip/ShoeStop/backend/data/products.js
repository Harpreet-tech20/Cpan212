const products = [
  // Men's Shoes
  {
    id: "1",
    name: "Nike Air Max",
    brand: "Nike",
    size: ["8", "9", "10"],
    price: 129.99,
    image: "http://localhost:3000/images/nike-air-max.png",
    category: "shoe",
    gender: "Men"
  },
  {
    id: "2",
    name: "Adidas UltraBoost",
    brand: "Adidas",
    size: ["7", "9", "11"],
    price: 149.99,
    image: "http://localhost:3000/images/adidas-ultraboost.jpg",
    category: "shoe",
    gender: "Men"
  },
  {
    id: "3",
    name: "Puma RS-X Efekt",
    brand: "Puma",
    size: ["8", "9", "10"],
    price: 109.99,
    image: "http://localhost:3000/images/puma-rsx-efekt.png",
    category: "shoe",
    gender: "Men"
  },

  // Women's Shoes
  {
    id: "4",
    name: "New Balance 574",
    brand: "New Balance",
    size: ["7", "8", "9"],
    price: 119.99,
    image: "http://localhost:3000/images/new-balance-574.jpg",
    category: "shoe",
    gender: "Women"
  },
  {
    id: "5",
    name: "Converse Chuck Taylor All Star",
    brand: "Converse",
    size: ["6", "7", "8", "9"],
    price: 69.99,
    image: "http://localhost:3000/images/converse-chuck-taylor.jpg",
    category: "shoe",
    gender: "Women"
  },
  {
    id: "6",
    name: "Reebok Classic Leather",
    brand: "Reebok",
    size: ["8", "9", "10"],
    price: 89.99,
    image: "http://localhost:3000/images/reebok-classic-leather.jpg",
    category: "shoe",
    gender: "Women"
  },

  // Kids' Shoes
  {
    id: "7",
    name: "Nike Air Force 1",
    brand: "Nike",
    size: ["8", "9", "10", "11"],
    price: 119.99,
    image: "http://localhost:3000/images/nike-air-force-1.png",
    category: "shoe",
    gender: "Kids"
  },
  {
    id: "8",
    name: "Adidas Samba OG",
    brand: "Adidas",
    size: ["7", "8", "9"],
    price: 94.99,
    image: "http://localhost:3000/images/adidas-samba-og.jpg",
    category: "shoe",
    gender: "Kids"
  },
  {
    id: "9",
    name: "Puma Suede Classic",
    brand: "Puma",
    size: ["8", "9", "10"],
    price: 74.99,
    image: "http://localhost:3000/images/puma-suede-classic.png",
    category: "shoe",
    gender: "Kids"
  },

  // Unisex Shoes
  {
    id: "10",
    name: "New Balance 327",
    brand: "New Balance",
    size: ["9", "10", "11"],
    price: 134.99,
    image: "http://localhost:3000/images/new-balance-327.jpg",
    category: "shoe",
    gender: "Men"
  },
  {
    id: "11",
    name: "Converse Run Star Hike",
    brand: "Converse",
    size: ["6", "7", "8"],
    price: 110.0,
    image: "http://localhost:3000/images/converse-run-star-hike.jpg",
    category: "shoe",
    gender: "Women"
  },
  {
    id: "12",
    name: "Reebok Nano X3",
    brand: "Reebok",
    size: ["8", "9", "10", "12"],
    price: 139.99,
    image: "http://localhost:3000/images/reebok-nano-x3.jpg",
    category: "shoe",
    gender: "Men"
  },

  // Men's Slippers
  {
    id: "101",
    name: "Comfy Foam Slippers",
    price: 19.99,
    image: "http://localhost:3000/images/comfy-foam-slippers.jpg",
    category: "slipper",
    gender: "Men"
  },

  // Women's Slippers
  {
    id: "102",
    name: "Luxury Velvet Slides",
    price: 29.99,
    image: "http://localhost:3000/images/luxury-velvet-slides.jpg",
    category: "slipper",
    gender: "Women"
  },

  // Kids' Slippers
  {
    id: "103",
    name: "Everyday Casual Slides",
    price: 15.99,
    image: "http://localhost:3000/images/everyday-casual-slides.jpg",
    category: "slipper",
    gender: "Kids"
  },
  {
    id: "104",
    name: "Cushion Flip Flops",
    price: 12.99,
    image: "http://localhost:3000/images/cushion-flip-flops.jpg",
    category: "slipper",
    gender: "Kids"
  }
];

module.exports = products;
