import "dotenv/config";
import mongoose from "mongoose";
import { connectDB } from "../config/db.js";
import User from "../models/User.js";
import Product from "../models/Product.js";
import bcrypt from "bcrypt";

(async () => {
  try {
    await connectDB(process.env.MONGODB_URI, process.env.DB_NAME);

    await Promise.all([User.deleteMany({}), Product.deleteMany({})]);

    const passwordHash = await bcrypt.hash("Passw0rd!", 10);
    await User.insertMany([
      { name: "Admin", email: "admin@shoestop.test", passwordHash, role: "admin" }
    ]);

    await Product.insertMany([
      {
        name: "Air Glide Runner",
        brand: "ShoeStop",
        category: "running",
        price: 119.99,
        inStock: 25,
        sizes: ["7","8","9","10","11"],
        colors: ["black","white"],
        description: "Lightweight running shoe.",
        images: []
      },
      {
        name: "Street Court Pro",
        brand: "ShoeStop",
        category: "casual",
        price: 89.99,
        inStock: 40,
        sizes: ["6","7","8","9","10"],
        colors: ["white","blue"],
        description: "Classic court style.",
        images: []
      }
    ]);

    console.log("✅ Seed complete");
    await mongoose.connection.close();
    process.exit(0);
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
})();
