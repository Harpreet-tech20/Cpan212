import mongoose from "mongoose";

export async function connectDB(uri, dbName) {
  try {
    await mongoose.connect(uri, { dbName });
    console.log(`✅ MongoDB connected → ${dbName}`);
  } catch (err) {
    console.error("❌ MongoDB connection error:", err.message);
    process.exit(1);
  }
  mongoose.connection.on("error", (e) => console.error("Mongo error:", e));
  mongoose.connection.on("disconnected", () => console.warn("Mongo disconnected"));
}
