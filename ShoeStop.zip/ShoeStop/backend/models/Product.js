import mongoose from "mongoose";

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 140 },
    brand: { type: String, trim: true },
    category: { type: String, trim: true, default: "shoes" },
    price: { type: Number, required: true, min: 0 },
    inStock: { type: Number, required: true, min: 0 },
    sizes: [{ type: String, trim: true }],
    colors: [{ type: String, trim: true }],
    description: { type: String, trim: true },
    images: [{ type: String, trim: true }]
  },
  { timestamps: true }
);

productSchema.index({ name: "text", brand: "text", category: "text" });

export default mongoose.model("Product", productSchema);
