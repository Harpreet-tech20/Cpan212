import Joi from "joi";

export const validate = (schema) => (req, res, next) => {
  const { error, value } = schema.validate(req.body, {
    abortEarly: false,
    stripUnknown: true
  });
  if (error) {
    return res.status(400).json({
      message: "Validation error",
      details: error.details.map(d => d.message)
    });
  }
  req.body = value;
  next();
};

export const schemas = {
  createUser: Joi.object({
    name: Joi.string().min(2).max(80).required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required()
  }),
  createProduct: Joi.object({
    name: Joi.string().max(140).required(),
    brand: Joi.string().allow(""),
    category: Joi.string().allow(""),
    price: Joi.number().min(0).required(),
    inStock: Joi.number().integer().min(0).required(),
    sizes: Joi.array().items(Joi.string()).default([]),
    colors: Joi.array().items(Joi.string()).default([]),
    description: Joi.string().allow(""),
    images: Joi.array().items(Joi.string()).default([])
  }),
  createOrder: Joi.object({
    user: Joi.string().required(),
    items: Joi.array().items(
      Joi.object({
        product: Joi.string().required(),
        name: Joi.string().required(),
        price: Joi.number().min(0).required(),
        size: Joi.string().allow(""),
        color: Joi.string().allow(""),
        quantity: Joi.number().integer().min(1).required()
      })
    ).min(1).required(),
    shippingAddress: Joi.object({
      line1: Joi.string().required(),
      line2: Joi.string().allow(""),
      city: Joi.string().required(),
      country: Joi.string().required(),
      postalCode: Joi.string().required()
    }).required()
  })
};
