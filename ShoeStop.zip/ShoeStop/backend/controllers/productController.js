import Product from "../models/Product.js";

export async function createProduct(req, res) {
  const product = await Product.create(req.body);
  res.status(201).json(product);
}

export async function listProducts(req, res) {
  const q = req.query.q;
  let filter = {};
  if (q) filter.$text = { $search: q };
  const products = await Product.find(filter).sort({ createdAt: -1 });
  res.json(products);
}

export async function getProduct(req, res) {
  const p = await Product.findById(req.params.id);
  if (!p) return res.status(404).json({ message: "Product not found" });
  res.json(p);
}

export async function updateProduct(req, res) {
  const p = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!p) return res.status(404).json({ message: "Product not found" });
  res.json(p);
}

export async function deleteProduct(req, res) {
  const p = await Product.findByIdAndDelete(req.params.id);
  if (!p) return res.status(404).json({ message: "Product not found" });
  res.json({ message: "Deleted", id: p._id });
}
