import Order from "../models/Order.js";

export async function createOrder(req, res) {
  const { items } = req.body;
  const total = items.reduce((sum, it) => sum + it.price * it.quantity, 0);
  const order = await Order.create({ ...req.body, total });
  res.status(201).json(order);
}

export async function listOrders(req, res) {
  const orders = await Order.find()
    .populate("user", "name email")
    .sort({ createdAt: -1 });
  res.json(orders);
}

export async function getOrder(req, res) {
  const o = await Order.findById(req.params.id).populate("user", "name email");
  if (!o) return res.status(404).json({ message: "Order not found" });
  res.json(o);
}
