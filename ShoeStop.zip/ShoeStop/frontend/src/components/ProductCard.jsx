import React from "react";
import { motion } from "framer-motion";
import "./ProductCard.css";

function ProductCard({ product, addToCart, onView }) {
  return (
    <motion.div
      className="product-card"
      whileHover={{ scale: 1.05 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <img src={product.image} alt={product.name} />
      <h4>{product.name}</h4>
      <p className="brand">{product.brand}</p>
      <p className="price">${product.price.toFixed(2)}</p>
      <div className="card-buttons">
        <button className="view-btn" onClick={() => onView(product.id)}>
          View
        </button>
        <button className="add-btn" onClick={() => addToCart(product)}>
          Add to Cart
        </button>
      </div>
    </motion.div>
  );
}

export default ProductCard;
