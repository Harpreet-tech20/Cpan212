import React from "react";
import { useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import "./FloatingCartButton.css";

function FloatingCartButton() {
  const navigate = useNavigate();
  const { cart } = useCart();
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <button className="floating-cart" onClick={() => navigate("/cart")}>
      🛒
      {totalItems > 0 && <span className="cart-badge">{totalItems}</span>}
    </button>
  );
}

export default FloatingCartButton;
