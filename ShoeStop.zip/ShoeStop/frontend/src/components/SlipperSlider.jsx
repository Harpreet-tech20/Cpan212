// src/components/SlipperSlider.jsx
import React from "react";
import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router-dom";
import "./SlipperSlider.css";

const slippers = [
  {
    id: "101",
    name: "Comfy Foam Slippers",
    price: 19.99,
    image: "/images/comfy-foam-slippers.jpg",
  },
  {
    id: "102",
    name: "Luxury Velvet Slides",
    price: 29.99,
    image: "/images/luxury-velvet-slides.jpg",
  },
  {
    id: "103",
    name: "Everyday Casual Slides",
    price: 15.99,
    image: "/images/everyday-casual-slides.jpg",
  },
  {
    id: "104",
    name: "Cushion Flip Flops",
    price: 12.99,
    image: "/images/cushion-flip-flops.jpg",
  },
];

function SlipperSlider() {
  const { addToCart } = useCart();
  const navigate = useNavigate();

  return (
    <div className="slider-section slippers-section">
      <h2 className="slider-heading">🥿 Shop Slippers</h2>
      <div className="product-grid">
        {slippers.map((item) => (
          <div className="product-card" key={item.id}>
            <img src={item.image} alt={item.name} />
            <h3>{item.name}</h3>
            <p className="price">${item.price.toFixed(2)}</p>
            <div className="button-group">
              <button onClick={() => navigate(`/product/${item.id}`)}>View</button>
              <button onClick={() => addToCart(item)}>Add to Cart</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default SlipperSlider;
