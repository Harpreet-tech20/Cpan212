import React from "react";
import "./FilterSidebar.css";

function FilterSidebar({ brands, sizes, selectedFilters, setSelectedFilters }) {
  const handleCheckboxChange = (type, value) => {
    const current = selectedFilters[type];
    const updated = current.includes(value)
      ? current.filter((v) => v !== value)
      : [...current, value];

    setSelectedFilters({ ...selectedFilters, [type]: updated });
  };

  const handlePriceChange = (e) => {
    setSelectedFilters({ ...selectedFilters, price: Number(e.target.value) });
  };

  return (
    <aside className="filter-sidebar">
      <h3>Filter by Brand</h3>
      {brands.map((brand) => (
        <label key={brand}>
          <input
            type="checkbox"
            checked={selectedFilters.brands.includes(brand)}
            onChange={() => handleCheckboxChange("brands", brand)}
          />
          {brand}
        </label>
      ))}

      <h3>Filter by Size</h3>
      {sizes.map((size) => (
        <label key={size}>
          <input
            type="checkbox"
            checked={selectedFilters.sizes.includes(size)}
            onChange={() => handleCheckboxChange("sizes", size)}
          />
          {size}
        </label>
      ))}

      <h3>Filter by Price</h3>
      <input
        type="range"
        min={0}
        max={200}
        value={selectedFilters.price}
        onChange={handlePriceChange}
      />
      <p>Max: ${selectedFilters.price}</p>
    </aside>
  );
}

export default FilterSidebar;
