import React from "react";
import Slider from "react-slick";
import "./BannerCarousel.css";

const banners = [
  "/images/banner1.jpg",
  "/images/banner2.jpg",
  "/images/banner3.jpg"
];

function BannerCarousel() {
  const settings = {
    dots: true,
    infinite: true,
    speed: 700,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000
  };

  return (
    <div className="banner-carousel">
      <Slider {...settings}>
        {banners.map((src, index) => (
          <div key={index} className="banner-slide">
            <img src={src} alt={`Banner ${index + 1}`} />
          </div>
        ))}
      </Slider>
    </div>
  );
}

export default BannerCarousel;
