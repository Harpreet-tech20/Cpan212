import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import { useNavigate } from "react-router-dom";
import "./FloatingCart.css";

function FloatingCart() {
  const { cartItems } = useContext(CartContext);
  const navigate = useNavigate();

  const totalItems = cartItems.length;

  return (
    <div className="floating-cart" onClick={() => navigate("/cart")}>
      🛒 {totalItems}
    </div>
  );
}

export default FloatingCart;
