import React from "react";
import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { useTheme } from "../context/ThemeContext";
import "./Navbar.css";

function Navbar() {
  const { cart } = useCart();
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const { darkMode, setDarkMode } = useTheme();

  return (
    <nav className="navbar">
      <div className="nav-left">
        <h1 className="logo">ShoeStop 👟</h1>
      </div>

      <ul className="nav-links">
        <li><Link to="/">🏠 Home</Link></li>
        <li><Link to="/search">🔍 Search</Link></li>
        <li><Link to="/register">📝 Register</Link></li>
        <li><Link to="/login">🔑 Login</Link></li>
        <li><Link to="/cart">🛒 Cart ({totalItems})</Link></li>
      </ul>

      <button className="theme-toggle" onClick={() => setDarkMode(!darkMode)}>
        {darkMode ? "☀ Light" : "🌙 Dark"}
      </button>
    </nav>
  );
}

export default Navbar;
