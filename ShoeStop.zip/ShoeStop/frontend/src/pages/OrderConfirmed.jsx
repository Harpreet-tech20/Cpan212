import Navbar from "../components/Navbar";
import { Link } from "react-router-dom";
import { jsPDF } from "jspdf";
import "./Confirm.css";

function OrderConfirmed() {
  const handleDownload = () => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("ShoeStop - Order Confirmation", 20, 20);
    doc.setFontSize(12);
    doc.text("Thank you for your order!", 20, 40);
    doc.text("This is your confirmation receipt for your recent ShoeStop purchase.", 20, 50);
    doc.text("You will receive your order in 3-5 business days.", 20, 60);
    doc.text("Website: www.shoestop.com", 20, 80);
    doc.save("ShoeStop_Invoice.pdf");
  };

  return (
    <>
      <Navbar />
      <div className="confirm-page">
        <h1>🎉 Order Confirmed!</h1>
        <p>Thank you for shopping at ShoeStop. Your shoes are on the way!</p>
        <div style={{ marginTop: "20px" }}>
          <button onClick={handleDownload} className="invoice-btn">Download Invoice (PDF)</button>
        </div>
        <Link to="/" className="continue-btn">Continue Shopping</Link>
      </div>
    </>
  );
}

export default OrderConfirmed;
