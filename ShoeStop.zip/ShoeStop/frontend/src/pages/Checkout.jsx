import React, { useState } from "react";
import { useCart } from "../context/CartContext";
import "./Checkout.css";
import jsPDF from "jspdf";

function Checkout() {
  const { cart, clearCart } = useCart();
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [orderPlaced, setOrderPlaced] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim() || !address.trim()) {
      alert("Please enter both name and address.");
      return;
    }
    setOrderPlaced(true);
    clearCart();
  };

  const generateInvoice = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text("ShoeStop Order Invoice", 20, 20);
    doc.setFontSize(12);
    doc.text(`Name: ${name}`, 20, 30);
    doc.text(`Address: ${address}`, 20, 40);
    doc.text("Products:", 20, 50);

    cart.forEach((item, idx) => {
      doc.text(
        `${idx + 1}. ${item.name} x${item.quantity} - $${item.price.toFixed(2)}`,
        20,
        60 + idx * 10
      );
    });

    const total = cart.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );
    doc.text(`Total: $${total.toFixed(2)}`, 20, 70 + cart.length * 10);
    doc.save("shoestop-invoice.pdf");
  };

  return (
    <div className="checkout-wrapper">
      <div className="checkout-container">
        <h2>🧾 Checkout</h2>
        {!orderPlaced ? (
          <form onSubmit={handleSubmit} className="checkout-form">
            <input
              type="text"
              placeholder="Full Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
            <input
              type="text"
              placeholder="Shipping Address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              required
            />
            <button type="submit">Submit Order</button>
          </form>
        ) : (
          <div className="confirmation">
            <h3>✅ Order Placed Successfully!</h3>
            <p>Thank you, <strong>{name}</strong>. Your order is on the way.</p>
            <button onClick={generateInvoice}>📄 Download Invoice</button>
            <a href="/" className="continue-link">Continue Shopping</a>
          </div>
        )}
      </div>
    </div>
  );
}

export default Checkout;
