import { useState } from "react";
import Navbar from "../components/Navbar";
import "./AuthForm.css";

function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    // Simple form validation
    if (!name || !email || !password) {
      setError("All fields are required.");
      setSuccess("");
      return;
    }

    setError("");
    setSuccess("Registration successful!");

    // Simulate backend submission
    console.log("Registering user:", { name, email, password });

    // Reset form
    setName("");
    setEmail("");
    setPassword("");
  };

  return (
    <>
      <Navbar />
      <div className="auth-page">
        <div className="auth-box">
          <h2>Register</h2>

          {error && <div className="error-message">{error}</div>}
          {success && <div style={{ color: "green", fontSize: "14px", marginBottom: "10px" }}>{success}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <input
                type="text"
                placeholder=" "
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
              <label>Full Name</label>
            </div>

            <div className="form-group">
              <input
                type="email"
                placeholder=" "
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <label>Email Address</label>
            </div>

            <div className="form-group">
              <input
                type="password"
                placeholder=" "
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <label>Password</label>
            </div>

            <button type="submit">Create Account</button>
          </form>
        </div>
      </div>
    </>
  );
}

export default Register;
