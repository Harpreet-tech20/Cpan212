import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import "./ProductPage.css";

function ProductPage() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    fetch("http://localhost:5000/products")
      .then((res) => res.json())
      .then((data) => {
        const selected = data.find((p) => p.id === id);
        setProduct(selected);
      })
      .catch((err) => console.error("Error fetching product:", err));
  }, [id]);

  if (!product) return <div className="product-loading">Loading...</div>;

  return (
    <div className="product-page">
      <div className="product-container">
        <img src={product.image} alt={product.name} className="product-image" />
        <div className="product-info">
          <h2>{product.name}</h2>
          <p><strong>Brand:</strong> {product.brand || "N/A"}</p>
          <p><strong>Price:</strong> ${product.price.toFixed(2)}</p>
          {product.size && (
            <p>
              <strong>Sizes:</strong> {product.size.join(", ")}
            </p>
          )}
          <p><strong>Category:</strong> {product.category}</p>
          <button className="buy-button">Add to Cart</button>
        </div>
      </div>
    </div>
  );
}

export default ProductPage;
