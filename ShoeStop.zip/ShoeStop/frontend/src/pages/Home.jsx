import React, { useEffect, useState } from "react";
import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router-dom";
import SlipperSlider from "../components/SlipperSlider";
import "./Home.css";
import { motion } from "framer-motion";

function Home() {
  const [products, setProducts] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [viewType, setViewType] = useState("grid");

  const [brandFilter, setBrandFilter] = useState([]);
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [sizeFilter, setSizeFilter] = useState("");
  const [priceRange, setPriceRange] = useState([0, 200]);

  const { addToCart } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:5000/products")
      .then((res) => res.json())
      .then((data) => {
        setProducts(data);
        setFiltered(data);
      })
      .catch((err) => console.error(err));
  }, []);

  useEffect(() => {
    let temp = [...products];

    if (categoryFilter !== "All") {
      temp = temp.filter((p) => p.category === categoryFilter);
    }

    if (brandFilter.length > 0) {
      temp = temp.filter((p) => brandFilter.includes(p.brand));
    }

    if (sizeFilter) {
      temp = temp.filter((p) => p.size?.includes(sizeFilter));
    }

    temp = temp.filter(
      (p) => p.price >= priceRange[0] && p.price <= priceRange[1]
    );

    setFiltered(temp);
  }, [categoryFilter, brandFilter, sizeFilter, priceRange, products]);

  const allBrands = [...new Set(products.map((p) => p.brand))];
  const allSizes = [...new Set(products.flatMap((p) => p.size || []))];

  const handleBrandChange = (brand) => {
    if (brandFilter.includes(brand)) {
      setBrandFilter(brandFilter.filter((b) => b !== brand));
    } else {
      setBrandFilter([...brandFilter, brand]);
    }
  };

  return (
    <div className="home-container">
      {/* Banner / Carousel */}
      <div className="hero-banner">
        <h1>🔥 Step Into Style</h1>
        <p>Men, Women & Kids Shoes Collection</p>
      </div>

      {/* Sidebar + Filters */}
      <div className="home-layout">
        <aside className="filters">
          <h3>Filter by Brand</h3>
          {allBrands.map((brand) => (
            <label key={brand}>
              <input
                type="checkbox"
                value={brand}
                checked={brandFilter.includes(brand)}
                onChange={() => handleBrandChange(brand)}
              />
              {brand}
            </label>
          ))}

          <h3>Filter by Size</h3>
          <select
            onChange={(e) => setSizeFilter(e.target.value)}
            value={sizeFilter}
          >
            <option value="">All Sizes</option>
            {allSizes.map((size) => (
              <option key={size}>{size}</option>
            ))}
          </select>

          <h3>Filter by Price</h3>
          <input
            type="range"
            min="0"
            max="200"
            step="5"
            value={priceRange[1]}
            onChange={(e) =>
              setPriceRange([priceRange[0], parseInt(e.target.value)])
            }
          />
          <p>Up to ${priceRange[1]}</p>

          <h3>Category</h3>
          <select
            onChange={(e) => setCategoryFilter(e.target.value)}
            value={categoryFilter}
          >
            <option value="All">All</option>
            <option value="shoe">Shoes</option>
            <option value="slipper">Slippers</option>
          </select>

          <h3>View</h3>
          <button onClick={() => setViewType("grid")}>🔳 Grid</button>
          <button onClick={() => setViewType("list")}>📃 List</button>
        </aside>

        {/* Product Display */}
        <div className={`product-display ${viewType}`}>
          {filtered.map((item) => (
            <motion.div
              className="product-card"
              key={item.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              <img src={item.image} alt={item.name} />
              <h3>{item.name}</h3>
              <p className="brand">{item.brand}</p>
              <p className="price">${item.price.toFixed(2)}</p>
              <div className="button-group">
                <button onClick={() => navigate(`/product/${item.id}`)}>
                  View
                </button>
                <button onClick={() => addToCart(item)}>Add to Cart</button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Home;
