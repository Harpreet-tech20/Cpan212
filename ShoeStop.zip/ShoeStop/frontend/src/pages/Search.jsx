import { useState } from "react";
import Navbar from "../components/Navbar";
import "./AuthForm.css";

function Search() {
  const [query, setQuery] = useState("");

  const handleSearch = (e) => {
    e.preventDefault();
    console.log("Searching for:", query);
  };

  return (
    <>
      <Navbar />
      <div className="auth-page">
        <div className="auth-box">
          <h2>Search Products</h2>
          <form onSubmit={handleSearch}>
            <input
              type="text"
              placeholder="Search for shoes..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              required
            />
            <button type="submit">Search</button>
          </form>
        </div>
      </div>
    </>
  );
}

export default Search;
