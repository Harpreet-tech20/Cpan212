import { useState } from "react";
import Navbar from "../components/Navbar";
import "./AuthForm.css";

function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleReset = (e) => {
    e.preventDefault();
    if (!email) {
      setMessage("Please enter your email address.");
      return;
    }
    setMessage("If this email exists, a reset link has been sent.");
  };

  return (
    <>
      <Navbar />
      <div className="auth-page">
        <div className="auth-box">
          <h2>Forgot Password</h2>
          {message && <div className="error-message">{message}</div>}
          <form onSubmit={handleReset}>
            <div className="form-group">
              <input
                type="email"
                placeholder=" "
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <label>Email Address</label>
            </div>
            <button type="submit">Send Reset Link</button>
          </form>
        </div>
      </div>
    </>
  );
}

export default ForgotPassword;
