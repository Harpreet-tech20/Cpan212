import { useParams } from "react-router-dom";
import axios from "axios";
import { useEffect } from "react";

function Profile() {
  const { id } = useParams();

  useEffect(() => {
    axios.get(`http://localhost:5000/api/user/${id}`)
      .then(res => console.log(res.data))
      .catch(err => console.log(err));
  }, [id]);

  return <h2>Profile Page for User ID: {id}</h2>;
}

export default Profile;
