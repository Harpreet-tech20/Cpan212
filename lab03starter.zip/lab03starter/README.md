To run this application:
Open 2 terminals, one to the server folder and one to the client folder

Server terminal:
  npm install
  npm run dev

Client terminal:
  npm install
  npm run dev
